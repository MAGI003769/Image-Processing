# Image Filtering in Frequency Domain



# Reference

- [2D-DCT](https://ww2.mathworks.cn/help/images/discrete-cosine-transform.html)